# weekly-report

一个用于生成和整理中文 Word 周报的 Codex skill。

它使用仓库内置的 Word 模板，保留 A4 页面、字体、页边距和严格的编号层级，并根据工作记录、论文笔记、实验结果或项目进展生成可编辑的周报。

## 适用场景

- 根据论文笔记整理研究周报
- 根据实验记录生成阶段性周报
- 根据项目进展生成中文 Word 周报
- 按固定模板清理和更新已有周报

## 默认行为

- 用户未提供日期时，标题使用执行当天的 `YYYY-MM-DD 周报`。
- `1.主要内容` 和 `2.具体内容` 根据输入材料整理，不编造实验结果、指标或完成状态。
- `[文献调研]` 标题后的正文保留为空，供用户补写。
- `3.下一步安排` 下的 `3.1` 正文保留为空，不从笔记推断计划。
- 标题居中、黑色；正文使用仿宋等效字体，英文和模型名使用 Times New Roman。

## 安装

将整个 `weekly-report` 目录复制到 Codex 的 skills 目录，例如：

```text
~/.codex/skills/weekly-report/
```

保持以下目录结构：

```text
weekly-report/
├── SKILL.md
├── README.md
├── agents/
│   └── openai.yaml
├── assets/
│   └── weekly-report-template.docx
└── references/
    └── template-format.md
```

安装后可以直接请求“根据这份笔记制作周报”，或显式使用 `$weekly-report`。

## 许可

本仓库未附带额外许可证。公开发布前，请为模板文件及技能内容选择并补充适合的许可证。
